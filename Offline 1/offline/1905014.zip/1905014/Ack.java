import java.io.Serializable;

public class Ack implements Serializable {
    Ack(){}
}
